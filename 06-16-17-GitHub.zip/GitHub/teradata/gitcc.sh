# GitHub section -----------------------------------------

#!/bin/sh
echo -e  "I'm doing something for GitHub now\n"

# the vob that is being migrated
   vob_name=$1
   view_name=$2
   
   echo -e  "VOB = $vob_name\n"
   
   echo -e  "View = $view_name\n"
   
cd $curr_dir

cd /c/cc_views/osutils_import/$view_name/osutils/src/linux-config

# update the gitcc copy of the files to import
echo -e  "Copy files from CC snap view to local git repo. \n"
gitcc update "$label $date"
while [ -f /c/cc_views/osutils_import/$view_name/.git/index.lock ]; do sleep 1; done
echo -e  " done.\n"

# push cc labels_tags to git remote repo (master)
echo -e  "Pushing to remote ...\n"
git add -A
echo -e  " done.\n"
echo -e  "commit label and date\n"
git commit -m "$label $date"
echo -e  " done.\n"
echo -e  "issung git branch and tag master_cc and master_ci\n"
git branch -f master_cc HEAD
git tag -f master_ci HEAD
echo -e  " done.\n"
echo -e  "issuing git tag label\n"
git tag $label
echo -e  " done.\n"

echo -e  "using gitcc program\n"
gitcc tag $label
git tag -f master_ci $label
echo -e  " done.\n"

# gitcc checkin files 
echo -e  "issue gitcc checkin. \n"
gitcc checkin --cclabel
#add a wait
git log -z --reverse --pretty=format:%H%x01%B --first-parent master_ci..
echo -e  " done.\n"  

# Push to origin
echo -e  "Push to origin. \n"
git push origin master
# git push -f origin master --repo https:/\name:password@domain.name\name/repo.git
echo -e  " done.\n"


# Push the label to origin
echo -e  "Push label to origin. \n"
git push origin $label
echo -e  "import completed\n"
rm -rf wrs
echo -e "completed deleting wrs directory."
ls -al

done < $filename