# pde.2 pde.2 pde.2 opnpde.2 vob
# Teradata script specific # version 1.0.0 - created by ayman mousa #
# Make sure label_dates.txt, tmp-spec.txt, and git_cspec files exists ######
# Command line to run the program: >>> ./script_name.sh \\vob_name     ######
# Use Git Shell $./clearcaseTasks.sh \\osutils \\am255098_view
# You need to be at the top of all vobs to be able to view label properties using cleartool command 
# V:\>cleartool catcs -tag TERADATA_TDSCHED_1.3.5.0_GCA

#!/bin/sh
echo -e  "getting ready for the migration now\n"

if [ $# -eq 0 ]
  then
      echo -e  "No arguments supplied"
          echo -e  "Please supply path to VOB name\n"
    exit 1
fi

# Script will be executed for the migration path'   
    curr_dir='/c/Users/am255098/Documents/GitHub/pde.2'

# File contains clearcase labels_name and dates
   filename='/c/Users/am255098/Documents/GitHub/pde.2/labels_dates.txt'

# a temp config spec will be used to load 
   cfgspec_name='/c/Users/am255098/Documents/GitHub/pde.2/tmp-spec.txt'

# verify if label has other dependecies based on configspec if not it will use same label to load   
   cspecs='/c/Users/am255098/Documents/GitHub/pde.2/git_cspecs'

# the vob that is being migrated
   vob_name=$1
   view_name=$2
   
   echo -e  "VOB = $vob_name\n"
   echo -e  "View = $view_name\n"

# for each label that is read out from the labels file
while read -a line; do 
	
		label=${line[0]}
		date=${line[1]}

    echo $label
	echo -e  " \n"
	echo $date
	echo -e  " \n"
	echo $label/$date
	echo -e  " \n"

		echo "element * CHECKEDOUT" > $cfgspec_name 
		
#		echo "element .../lost+found -none" > $cfgspec_name

	cd /c/cc_views/osutils_import/$view_name
	cleartool setcs -force -overwrite -pti /c/Users/am255098/Documents/GitHub/pde.2/tmp-spec.txt
	cd $curr_dir

# catcs: lists a view's config spec
# setcs: makes a specified file a view's config spec
# update add_loadrules: adds load rules to the config spec of a snapshot view while updating the view
		
	mv osutils.unloaded osutils
	
### >>> see if a config spec in is the config spec area
	if test -r $cspecs/$label; then
		### >>> if it is, then use that one
		cat $cspecs/$label >> $cfgspec_name
	else

### >>> otherwise make one from just the label & add /main/LATEST
	        echo "element * $label" >>        $cfgspec_name
			echo "element * /main/LATEST" >> $cfgspec_name	
	fi

	echo "load $vob_name" >>      $cfgspec_name 

	echo -e  " \n"
	echo -e  "-------------------------------\n"
	echo -e  "contents of $cfgspec_name for label $label\n" 
	echo -e  "-------------------------------\n"
	
	cat $cfgspec_name

	echo -e  "setting config spec...\n"
	# set the config spec.  This will update all the files in the current view
	cd /c/cc_views/osutils_import/$view_name
	cleartool setcs -force -overwrite -pti /c:/Users/am255098/Documents/GitHub/pde.2/tmp-spec.txt
		pwd
		echo -e  " \n"
		echo -e  "Current config spec set to...\n"
	cleartool catcs
		echo -e  " \n"

cd $curr_dir

cd /c/cc_views/osutils_import/$view_name

# update cc2git copy of the files to GitHub import -----------------------------------------
echo -e  "I'm doing something in GitHub now\n"

# the vob that is being migrated
   vob_name=$1
   view_name=$2
   
		echo -e  "VOB = $vob_name\n"
   		echo -e  "View = $view_name\n"
   
	cd $curr_dir
	
echo -e  "Where I'm at now +++++++++++++++++++++++++++++++++++++++++\n"
cd /c/cc_views/osutils_import/$view_name
echo -e  "View = $view_name +++++++++++++++++++++++++++++++++++++++++\n"

	ls -la; sleep 10
#		cd ./osutils/src/linux-config/

#	ls -la 

#to hard code the path you can use cd /c/cc_views/osutils_import/am255098_view1/osutils/src/linux-config/

# update the git&cc copy of the files to import
echo -e  "Copy files from CC snap view to local git repo. \n"

#look for .lock file"
while [ -f /c/cc_views/osutils_import/$view_name/.git/index.lock ]; do sleep 1; done
echo -e  " done.\n"

# hard code and move to the folder and files to go to github
#cd /c/cc_views/osutils_import/am255098_view1/osutils/src/linux-config/

#add a step rename the vob_view to the 
#mv $ 

# push cc labels_tags to git remote repo (master)
echo -e  "Pushing to remote ...\n"
git add -A
echo -e  " done.\n"
echo -e  "commit label and date\n"
git commit -m "$label $date"
echo -e  "done.\n"
echo -e  "Issung git branch and tag master_cc and master_ci\n"
git branch -f master_cc HEAD
git tag -f master_ci HEAD
echo -e  " done.\n"
echo -e  "Issuing git tag label\n"
git tag $label
echo -e  " done.\n"
echo -e  "using github program\n"
git tag -f master_ci $label
echo -e  " done.\n"
echo -e  "issue gitcc checkin. \n"

#add a wait
git log -z --reverse --pretty=format:%H%x01%B --first-parent master_ci..
echo -e  " done.\n"  

# Push to origin
echo -e  "Push to origin. \n"
git push origin master

#git push -f origin master --repo https:/\name:password@domain.name\name/repo.git
echo -e  " done.\n"

# Push the label to origin
echo -e  "Push label to origin. \n"
git push origin $label
echo -e  "import completed\n"

	rm -rf $view_name
		echo -e "completed deleting view_name directory."
ls -al

done < $filename
