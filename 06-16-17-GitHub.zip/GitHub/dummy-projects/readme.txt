#### Introduction
#### This is docker image that builds jenkin imag on ubuntu with "jdk8" and maven 3.3.9
#### Build
#### docker build -t am255098/jenkins:latest .
#### for jenkins latest means latest version and you don't have to specify a version # 
#### Run 