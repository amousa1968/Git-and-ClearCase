# '$#' shell variable contains the number of positional arguments to a script or function.


set -X

#!/bin/sh
./clearcasePDE.sh \\opnpde \\am255098_cc2git_dynamic_test &

for i in `echo 1, 2, 3, 4, 5, 6, 7, 8, 9, a, b`; do
	./clearcasePDE.sh \\opnpde.${i} arg2 &

done 


# ./clearcasePDE.sh \\opnpde \\am255098_cc2git_dynamic_test 
#./clearcasePDE.sh \\opnpde.1 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.2 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.3 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.4 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.5 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.6 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.7 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.8 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.9 \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.a \\am255098_cc2git_dynamic_test
#./clearcasePDE.sh \\opnpde.b \\am255098_cc2git_dynamic_test
