set -x
#!/bin/sh

cd /c/cc_views/osutils_import/$view_name
#exit 

# execute script
sh /c/Users/am255098/Documents/GitHub/cc2git_dynamic_test/copyfilestomain.sh

##### This section is all about GitHub ##########################################

# update cc2git copy of the files to GitHub import -----------------------------------------
	echo -e  "Copy files from CC view to GitHub repository opnpde. \n"

# the vob that is being migrated
	vob_name=${1}
	vob1_name=${2}
	vob2_name=${3}
	vob3_name=${4}
	vob4_name=${5}
	vob5_name=${6}
	vob6_name=${7}
	vob7_name=${8}
	vob8_name=${9}
	vob9_name=${10}
	vob10_name=${11}
	vob11_name=${12}

	view_name=${13}
	
#	echo $@
	
	echo -e  "VOB = $vob_name\n"
	echo -e  "VOB = $vob1_name\n"
	echo -e  "VOB = $vob2_name\n"
	echo -e  "VOB = $vob3_name\n"
	echo -e  "VOB = $vob4_name\n"
	echo -e  "VOB = $vob5_name\n"
	echo -e  "VOB = $vob6_name\n"
	echo -e  "VOB = $vob7_name\n"
	echo -e  "VOB = $vob8_name\n"
	echo -e  "VOB = $vob9_name\n"
	echo -e  "VOB = $vob10_name\n"
	echo -e  "VOB = $vob11_name\n"

	echo -e  "View = $view_name\n"

	echo -e  "Where I'm at now +++++++++++++++++++++++++++++++++++++++++\n"
	echo -e  "View = $view_name +++++++++++++++++++++++++++++++++++++++++\n"

	ls -la; sleep 10

cd $curr_dir
cd /c/cc_views/osutils_import/$view_name/opnpde	
    echo -e  "opnpde"
# update the git&cc copy of the files to import
echo -e  "Copy files from CC snap view to local git repo. \n"

#look for .lock file"
 while [ -f /c/cc_views/osutils_import/$view_name/.git/index.lock ]; do sleep 1; done
	echo -e  " done.\n"
	
# push cc labels_tags to git remote repo (master)
echo -e  "Pushing to remote ...\n"
git add -A
	echo -e  " done.\n"
	echo -e  "commit product and release\n"
git commit -m "$label $date"
	echo -e  "done.\n"
	echo -e  "Issung git branch and tag master_cc and master_ci\n"
git branch -f master_cc HEAD
git tag -f master_ci HEAD
	
#git branch -f opnpde_6.0.2.x HEAD	 
#git tag -f opnpde_6.0.2.x HEAD
	echo -e  " done.\n"
	echo -e  "Issuing git tag release\n"
git tag $label
	echo -e  " done.\n"
	echo -e  "using github program\n"
git tag -f master_ci $label
	echo -e  " done.\n"
	echo -e  "issue gitcc checkin. \n"

#add a wait
git log -z --reverse --pretty=format:%H%x01%B --first-parent master_ci..
	echo -e  " done.\n"  

# Push to origin
	echo -e  "Push to origin. \n"
git push origin master
#git push -f origin master --repo https:/\name:password@domain.name\name/repo.git
	echo -e  " done.\n"

# Push the label to origin
	echo -e  "Push label to origin. \n"
git push origin $label
	echo -e  "import completed\n"

	rm -rf $view_name

	echo -e "completed deleting view_name directory."
	ls -al

done < $filename

#exit 