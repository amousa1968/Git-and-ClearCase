set -x
#!/bin/sh
if [ "$s1" == "$s2" ]; then echo match; fi

test "s1" = "s2" ;echo match
echo -e "test me" 
