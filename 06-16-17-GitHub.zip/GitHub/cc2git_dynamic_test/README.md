## Just with bash shell <formula>. This is the default source code by ayman.

# teradata pde product clearcase migration to github by amousa
![](https://sdlc6095.labs.teradata.com/pde/blob/master/teradata-pde.jpg)



#teradata pde product clearcase migration to github by amousa
