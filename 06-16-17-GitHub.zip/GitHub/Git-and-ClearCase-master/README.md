# Git-and-ClearCase 

Git and ClearCase
Initial configuration

#### Read this before you start the migration between clearcase & git  ######
#### Make sure you have the following directories for CC and Git existed on the desktop will be executing the script ######
#### Make sure label_dates.txt, tmp-spec.txt, and git_cspec files existes ######
#### Save the changes!!!!												  ######
#### Command line to run the program: >>> ./script_name.sh \\vob_name     ######
#### ./clearcase2git_migration.sh \\cc_snaps\kl_wrs_import            ######


More to come 
