#!/bin/sh
echo -e  "hello\n"

if [ $# -eq 0 ]
  then
      echo -e  "No arguments supplied"
          echo -e  "Please supply path to VOB name\n"
    exit 1
fi

   curr_dir='/c/Users/am255098/bb_import_scripts/wrs'
   # list of label names
   filename='/c/Users/am255098/bb_import_scripts/wrs/labels_dates.txt'

   # a temp config spec to update and load
   cfgspec_name='/c/Users/am255098/bb_import_scripts/wrs/tmp-spec.txt'

   cspecs='/c/Users/am255098/bb_import_scripts/wrs/git_cspecs'

   # the vob that is being migrated
   vob_name=$1

   echo -e  "VOB = $vob_name\n"

   # for each label that is read out fo the labels file
while read -a line; do 

        label=${line[0]}
        date=${line[1]}
				        
	echo $label
	echo -e  " \n"
	echo $date
	echo -e  " \n"
	echo $label/$date
	echo -e  " \n"

	# LOG=/c/Users/am255098/bb_import_scripts/wrs/logs/$label.txt
	# echo -e "Logfile = $LOG \n"

    # add these lines to the config spec
	# checkedout is required at the first item in a snapshot config spec
        
		
		echo "element * CHECKEDOUT" > $cfgspec_name 
		echo "element .../lost+found -none" > $cfgspec_name 


	cd /c/cc_snaps/kl_import_wrs
	cleartool setcs -force -overwrite -pti /c/Users/am255098/bb_import_scripts/wrs/tmp-spec.txt
	cd $curr_dir
	
	### >>> see if a config spec in is the config spec area
	if test -r $cspecs/$label; then
		### >>> if it is, then use that one
		cat $cspecs/$label >> $cfgspec_name
	else
	        ### >>> otherwise make one from just the label
	        echo "element * $label" >>        $cfgspec_name 
	fi

	echo "load $vob_name" >>      $cfgspec_name 

	echo -e  " \n"
	echo -e  "-------------------------------\n"
	echo -e  "contents of $cfgspec_name for label $label\n" 
	echo -e  "-------------------------------\n"
	
	cat $cfgspec_name

	echo -e  "setting config spec...\n"
	# set the config spec.  This will update all the files in the current view
	cd /c/cc_snaps/kl_import_wrs
	cleartool setcs -force -overwrite -pti /c/Users/am255098/bb_import_scripts/wrs/tmp-spec.txt
	pwd
	echo -e  " \n"
	echo -e  "Current config spec set to...\n"
	cleartool catcs
	echo -e  " \n"

cd $curr_dir

cd /c/bitbucket_migration/kl_raptor_run_5/itek_wrs

# update the gitcc copy of the files to import
echo -e  "Copy files from CC snap view to local git repo. \n"
gitcc update "$label $date"
while [ -f /c/bitbucket_migration/kl_raptor_run_5/itek_wrs/.git/index.lock ]; do sleep 1; done
echo -e  " done.\n"

# push cc labels_tags to git remote repo (master)
echo -e  "Pushing to remote ...\n"
git add -A
echo -e  " done.\n"
echo -e  "commit label and date\n"
git commit -m "$label $date"
echo -e  " done.\n"
echo -e  "issung git branch and tag master_cc and master_ci\n"
git branch -f master_cc HEAD
git tag -f master_ci HEAD
echo -e  " done.\n"
echo -e  "issuing git tag label\n"
git tag $label
echo -e  " done.\n"

echo -e  "using gitcc program\n"
gitcc tag $label
git tag -f master_ci $label
echo -e  " done.\n"

# gitcc checkin files 
echo -e  "issue gitcc checkin. \n"
gitcc checkin --cclabel
#add a wait
git log -z --reverse --pretty=format:%H%x01%B --first-parent master_ci..
echo -e  " done.\n"  

# Push to origin
echo -e  "Push to origin. \n"
git push origin master
# git push -f origin master --repo https:/\name:password@domain.name\name/repo.git
echo -e  " done.\n"


# Push the label to origin
echo -e  "Push label to origin. \n"
git push origin $label
echo -e  "import completed\n"
rm -rf wrs
echo -e "completed deleting wrs directory."
ls -al

done < $filename
