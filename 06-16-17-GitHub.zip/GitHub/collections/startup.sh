# replace "$YOUR_SERVICE_NAME" with your service's name (whenever it's not enough obvious)
# cp "service.sh" "/etc/init.d/$YOUR_SERVICE_NAME"
# chmod +x /etc/init.d/$YOUR_SERVICE_NAME

#!/bin/bash on the first line, meaning that the script should always be run with bash

echo "Hello World" &> C:/Users/am255098/Documents/GitHub/hello.txt
