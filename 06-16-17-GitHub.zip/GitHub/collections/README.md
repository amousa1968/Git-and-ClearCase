jenkins-docker-job
=====================

This is a project that Jenkins execute tests in Docker.

The Python module [lxml](http://lxml.de/) requires packages `libxml2-dev` and `libxslt-dev` to build.
Using [Docker](http://www.docker.io/), you can execute a job in a seprated environment and can install these packages in the environment.

Jenkins job configuration
-------------------------


