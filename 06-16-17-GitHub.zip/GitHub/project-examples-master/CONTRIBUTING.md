# JFrog welcomes community contribution!

Before we can accept your contribution, process your GitHub pull requests, and thank you full heartedly, we request that you will fill out and submit JFrog's Contributor License Agreement (CLA).

[Click here](https://secure.echosign.com/public/hostedForm?formid=5IYKLZ2RXB543N) to submit the JFrog CLA.
This should only take a minute to complete and is a one-time process.

*Thanks for Your Contribution to the Community!* :-)
