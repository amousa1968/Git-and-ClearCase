﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace multi3
{
    public class Multi3
    {
        static void Main(string[] args)
        {
            new MyLogger.MyLogger().log("Hello from Multi3!");
        }
    }
}
