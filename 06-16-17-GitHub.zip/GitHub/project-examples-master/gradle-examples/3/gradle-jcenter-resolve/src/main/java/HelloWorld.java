/**
 * Hello world!
 */
import org.apache.commons.lang.StringUtils;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println(StringUtils.capitalize("hello world"));
    }
}