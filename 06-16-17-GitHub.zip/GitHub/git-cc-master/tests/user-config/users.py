users = {
    'charleso': "Charles O'Farrell",\
    'jki': 'Jan Kiszka <jan.kiszka@web.de>',\
}

mailSuffix = 'example.com'
