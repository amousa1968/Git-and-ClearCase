function show_help()
{
  IT=$(CAT <<EOF

  Have you run your unit tests yet? If so, pass OK or a branch name, and try again

  usage: git_push_new_branch {OK|BRANCH_NAME}

  e.g. 

  git_push_new_branch.sh           -> displays prompt reminding you to run unit tests
  git_push_new_branch.sh OK        -> pushes the current branch as a new branch to the origin
  git_push_new_branch.sh MYBRANCH  -> pushes branch MYBRANCH as a new branch to the origin

  )
  echo "$IT"
  exit
}

if [ -z "$1" ]
then
  show_help
fi

CURR_BRANCH=$(git rev-parse --abbrev-ref HEAD)
if [ "$1" == "OK" ]
then
  BRANCH=$CURR_BRANCH
else
  BRANCH=${1:-$CURR_BRANCH}
fi

function old()
{
  git push --set-upstream origin $BRANCH
  git push
}

git push -u origin $BRANCH